const express = require('express');

const bodyParser = require('body-parser');

const morgan = require('morgan');

const mongojs = require('mongojs');

const jwt = require('jsonwebtoken');

const config = require('./config');

const fetch = require('node-fetch');

const app = express();
const cors = require('cors');
const db = mongojs('smart-switch-db', ['users']);

app.set('secret', config.secret);
app.use(cors());
app.use(bodyParser.json());

// when extended is true, it will allow complex objects. 
// complex object is object inside object
app.use(bodyParser.urlencoded({extended: false}))

app.use(morgan("dev"));

app.get('/',(request, response) =>  {
    response.send('<h1>Welcome to smart switch server</h1>');
});

app.post('/register', (request, response)=>{
    db.users.findOne({'email': request.body.email}, (error1, user1) =>{
        if(error1)
            throw error1;
        if(!user1){
            db.users.insert(
                {
                    'name': request.body.name,
                    'email': request.body.email,
                    'password': request.body.password,
                    'securityQue': request.body.securityQue,
                    'securityAns': request.body.securityAns
                },
                (error, user) =>{
                if(error)
                    throw error;
                if(!user){
                    response.json({
                        success: false, message: 'Something went wrong'
                    });
                }
                else if(user){
                    response.json({
                        success: true, message: 'User successfully added'
                    });
                }    
            });
        }
        else if(user1){
            response.json({
                success: false, message: 'User with this email already exists'
            });
        }    
    });
});

app.post('/forgot-password', (request, response)=>{
    db.users.findOne({'email': request.body.email}, (error, user) =>{
        if(error)
            throw error;
        if(!user){
            response.json({
                success: false, message: 'Please check email'
            });
        }
        else if(user){
           if(user.securityQue !== request.body.securityQue || user.securityAns !== request.body.securityAns){
                response.json({
                    success: false, message: 'Please enter correct security question and answer'
                });
           }
           else{
               console.log(user);
               response.json({
                    success: true, message: 'Your password is <b>' + user.password + '</b>'
                });
           }
        }    
    });
});

const authRoutes = express.Router();
authRoutes.post('/auth', (request, response)=>{
    db.users.findOne({'email': request.body.email}, (error, user) =>{
        if(error)
            throw error;
        if(!user){
            response.json({
                success: false, message: 'Please check email'
            });
        }
        else if(user){
           if(user.password !== request.body.password){
                response.json({
                    success: false, message: 'Please check password'
                });
           }
           else{
               var token = jwt.sign(user, app.get('secret'), {
                   expiresIn: 2000 // in seconds
               });
               response.json({
                    success: true, message: 'Please save this token for the next request', token: token
                });
           }
        }    
    });
});

authRoutes.use((request, response, next)=>{
    let token = request.body.token || request.query.token || request.headers["x-access-token"];
    if(token){
        jwt.verify(token, app.get('secret'), (error, decoded)=>{
            if(error){
                return response.json({
                    success: false, message: 'We are unable to verify token'
                });
            }
            else{
                request.decoded =decoded;
                next();
            }
        });
    }
    else{
        return response.json({
            success: false, message: 'Please send the valid token'
        });
    }
});

authRoutes.get('/start', (request, response)=>{
    const buttonName = 'start' + request.query.q;
    let url = 'http://192.168.4.1/' + buttonName;
    if (request.query.q === 8) {
        url = url + '?servoPOS=' + request.query.servoPOS;
    } 
    fetch(url)
    .then(res => res.text())
    .then(body => response.json({message:"switch started"}));
});

authRoutes.get('/end', (request, response)=>{
    const buttonName = 'end' + request.query.q;
    const url = 'http://192.168.4.1/' + buttonName;
    fetch(url)
    .then(res => res.text())
    .then(body => response.json({message:"switch ended"}));
});

authRoutes.get('/', (request, response)=>{
    response.json({success:true});
});

app.use('/api', authRoutes);

app.listen(config.port, ()=>{
    console.log(`auth service is listening on PORT : ${config.port}`);
});