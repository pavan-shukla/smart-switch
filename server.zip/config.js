module.exports = {
    secret: 'smartswitchsecret',
    port: 4300
}