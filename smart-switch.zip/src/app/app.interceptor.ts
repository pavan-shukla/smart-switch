import { HttpEvent, HttpHandler, HttpHeaders, HttpInterceptor, HttpRequest } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { Observable } from "rxjs";
import { AppConstants } from "./app.constant";

@Injectable()
export class AppInterceptor implements HttpInterceptor {
    intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
        let hdrs = new HttpHeaders();
        hdrs = hdrs.append('content-type', 'application/json');
        hdrs = hdrs.append('x-access-token', AppConstants.token);
        const newReq = req.clone({
            headers: hdrs
        });
        return next.handle(newReq);
    }

}