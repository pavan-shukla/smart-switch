import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AppConstants } from '../app.constant';

@Component({
  selector: 'app-forgot-password',
  templateUrl: 'forgot-password.page.html',
  styleUrls: ['forgot-password.page.scss'],
})
export class ForgotPasswordPage implements OnInit {
  forgotPasswordForm: FormGroup;
  
  isMessageVisible = false;
  isSuccessMessageVisible = false;
  messageText: string = '';
  constructor(
    private http: HttpClient,
    private fb: FormBuilder,
    private router: Router
  ) {}

  ngOnInit() {
    this.createForgotPasswordForm();
  }

  createForgotPasswordForm() {
    this.forgotPasswordForm = this.fb.group({
      email: [undefined, [Validators.required]],
      securityQue: ['', [Validators.required]],
      securityAns: [undefined, [Validators.required]],
    });
  }

  forgotPassword() {
    if (this.forgotPasswordForm.valid) {
      const reqBody = {
        email: this.forgotPasswordForm.controls['email'].value,
        securityQue: this.forgotPasswordForm.controls['securityQue'].value,
        securityAns: this.forgotPasswordForm.controls['securityAns'].value
      };
      this.http.post(AppConstants.API_URL + 'forgot-password', reqBody).subscribe(
        (data: any) => {
          if (data.success) {
            this.isSuccessMessageVisible = true;
            this.messageText = data.message;
          } else {
            this.isMessageVisible = true;
            this.messageText = data.message;
          }
        },
        (error) => {
        }
      );
    }
  }

  hideSuccessMessage() {
    this.isSuccessMessageVisible = false;
    this.forgotPasswordForm.reset();
    this.router.navigate(['/login']);
  }

  hideMessage() {
    this.isSuccessMessageVisible = false;
    this.isMessageVisible = false;
    this.messageText = '';
  }
}
