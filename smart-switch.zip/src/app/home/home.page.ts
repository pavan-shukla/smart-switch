import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { AppConstants } from '../app.constant';

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
})
export class HomePage implements OnInit {

  public devices = [
    'device 1',
    'device 2',
    'device 3',
    'device 4',
    'device 5',
    'device 6',
    'Fan'
  ];
  public deviceStatus: any = {};
  public x = 10;
  public num = 0;
  apiURL = 'http://localhost:4300/';

  constructor(
    private http: HttpClient,
    private router: Router
  ) {
  }

  initializeApp() {
  }

  ngOnInit() {
  }

  // addDevice() {
  //   this.devices.unshift({
  //     name: `Device ${this.devices.length+1}`
  //   });
  // }

  deviceActionClick(device, operation: string, index) {
    if (operation === 'ON') {
      this.makeApiCall('start', (index + 1), device, operation);
    } else if (operation === 'OFF') {
      this.makeApiCall('end', (index + 1), device, operation);
    }
  }

  // editClick(device) {

  // }

  // deleteClick(device) {
  //   let deviceIndex;
  //   this.devices.map((value, index) => {
  //     if (device.id === value.id) {
  //       deviceIndex = index;
  //     }
  //   });
  //   if (deviceIndex >= 0) {
  //     this.devices.splice(deviceIndex, 1);
  //   }
  // }

  makeApiCall(buttonName, deviceNum , device, operation) {
    let url = this.apiURL + 'api/' + buttonName + '?q=' + deviceNum;
    if (buttonName === 'fanSpeed') {
      url = this.apiURL + 'api/start?q=8&servoPOS=' + this.num;
    }
    this.http.get(url).subscribe(data => {
      this.deviceStatus[device] = operation;
      if (device === 'Fan') {
        this.num = 0;
      }
    },
    error => {
      this.deviceStatus[device] = operation;
      if (device === 'Fan') {
        this.num = 0;
      }
    });
  }

  logout() {
    AppConstants.token = '';
    this.router.navigate(['/login']);
  }

  changeNum() {
    this.makeApiCall('fanSpeed', this.num, 8, 'ON')
  }

}
