import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AppConstants } from '../app.constant';

@Component({
  selector: 'app-register',
  templateUrl: 'register.page.html',
  styleUrls: ['register.page.scss'],
})
export class RegisterPage implements OnInit {

  registerForm: FormGroup;

  constructor(
    private http: HttpClient,
    private fb: FormBuilder,
    private router: Router
  ) {
  }

  ngOnInit() {
    this.createRegisterForm();
  }

  createRegisterForm() {
    this.registerForm = this.fb.group({
      name: [undefined, [Validators.required]],
      email: [undefined, [Validators.required]],
      password: [undefined, [Validators.required]],
      rePassword: [undefined, [Validators.required]],
      securityQue: ['', [Validators.required]],
      securityAns: [undefined, [Validators.required]]
    });
  }

  registerUser() {
    if (this.registerForm.valid) {
      const reqBody = {
        name: this.registerForm.controls['name'].value,
        email: this.registerForm.controls['email'].value,
        password: this.registerForm.controls['password'].value,
        securityQue: this.registerForm.controls['securityQue'].value,
        securityAns: this.registerForm.controls['securityAns'].value
      }
      this.http.post(AppConstants.API_URL + 'register', reqBody).subscribe(
        data=> {
          this.registerForm.reset();
          this.router.navigate(['/login']);  
        }, error => {
          // todo popup message of error
        }
      );
    }
  }

}
