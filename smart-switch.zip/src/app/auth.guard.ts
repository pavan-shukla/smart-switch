import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { ActivatedRouteSnapshot, CanActivate, Router, RouterStateSnapshot, UrlTree } from "@angular/router";
import { Observable } from "rxjs";
import { AppConstants } from "./app.constant";
@Injectable({
    providedIn: 'root'
})
export class AuthGuard implements CanActivate {

    constructor(private http: HttpClient, private router: Router) {}

    canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean | UrlTree | Observable<boolean | UrlTree> | Promise<boolean | UrlTree> {
        return new Promise(res => this.http.get(AppConstants.API_URL + 'api').subscribe(
            (data: any) => {
                if (data.success) {
                    return res(true);
                } else {
                    AppConstants.token = '';
                    this.router.navigate(['/login']);
                    return res(false);
                }
            }
        ));
    }

}