export class AppConstants {
    public static readonly API_URL = 'http://localhost:4300/';
    public static token = '';
}