import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AppConstants } from '../app.constant';

@Component({
  selector: 'app-login',
  templateUrl: 'login.page.html',
  styleUrls: ['login.page.scss'],
})
export class LoginPage implements OnInit {

  loginForm: FormGroup;

  isMessageVisible = false;
  messageText: string = '';

  constructor(
    private http: HttpClient,
    private fb: FormBuilder,
    private router: Router
  ) {
  }

  ngOnInit() {
    this.createLoginForm();
  }

  createLoginForm() {
    this.loginForm = this.fb.group({
      email: [undefined, [Validators.required]],
      password: [undefined, [Validators.required]]
    });
  }

  loginUser() {
    if (this.loginForm.valid) {
      const reqBody = {
        email: this.loginForm.controls['email'].value,
        password: this.loginForm.controls['password'].value
      };
      this.http.post(AppConstants.API_URL + 'api/auth', reqBody).subscribe(
        (data: any) => {
          if (data.success) {
            this.loginForm.reset();
            AppConstants.token = data.token;
            this.router.navigate(['/home']);
          } else {
            this.isMessageVisible = true;
            this.messageText = data.message;
          }
        }, (error: any) => {
          console.log(error);
        }
      );
    }
  }
  
  hideMessage() {
    this.isMessageVisible = false;
    this.messageText = '';
  }

}
